<?php

$l['repbars_18_reputation'] = "Reputation";
$l['repbars_18_reputation_bar'] = "Reputation Bar";
$l['repbars_18_reputation_bars'] = "Reputation Bars";
$l['repbars_18_reputation_bars_legend'] = "Reputation Bars Legend";
$l['repbars_18_no_reputation_bars'] = "There currently exists no reputation bars";
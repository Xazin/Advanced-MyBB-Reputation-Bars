<?php

$l['repbars_18_reputation'] = "Reputation";